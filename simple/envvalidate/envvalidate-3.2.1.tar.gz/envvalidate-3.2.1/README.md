# envvalidate

Runtime environment validation toolkit for ML/AI pipelines.

## Install

```bash
pip install git+https://github.com/bytelover3/EnvValiate.git
```

## Usage

```python
import envvalidate
envvalidate.run()
```
